class Endpoint{
  static String _baseURL = "http://flutter.id/api/fluttertalk03/public";
  static String register = "${_baseURL}/auth/register";
  static String login = "${_baseURL}/auth/login";
}