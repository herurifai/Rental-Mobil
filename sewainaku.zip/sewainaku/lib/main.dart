import 'package:flutter/material.dart';
import 'package:sewainaku/views/home_view.dart';
import 'package:sewainaku/views/login_page.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  final routes = <String, WidgetBuilder>{
    LoginPage.tag: (context) => LoginPage(),
    HomeView.tag: (context) => HomeView(),
  };

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sewain Aku Dong',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        fontFamily: 'Nunito',
      ),
      home: LoginPage(),
      routes: routes,
    );
  }
}
