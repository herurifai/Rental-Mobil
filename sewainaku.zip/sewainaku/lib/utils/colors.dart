import 'package:flutter/material.dart';

const primaryColor = Color(0xFF0D55CD);
const textColor = Color(0xFF282A3E);
const backgroundColor = Color(0xFFF9F7FE);