package com.example.sewainaku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
